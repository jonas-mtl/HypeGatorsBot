export const icon = {
    color: {
        red: '<:icon_red:970322600771354634>',
        yellow: '<:icon_yellow:970322601887023125>',
        green: '<:icon_green:970322600930721802>',
        blue: '<:icon_blue:970322601878638712>',
    },
    reply: {
        default: '<:icon_Reply:1011384937884155914>',
        continue: {
            start: '<:icon_ReplyContinue1:962547429813657611>',
            mid: '<:icon_ReplyContinue2:962547430061125632>',
            end: '<:icon_ReplyContinue3:962547429947867166>',
        },
    },
};
