import { BaseClient } from './Structures/Classes/Client.js';

const client = new BaseClient();

console.clear();
client.start();
